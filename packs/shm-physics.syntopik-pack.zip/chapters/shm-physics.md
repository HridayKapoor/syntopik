# Simple Harmonic Motion — Linearization, Phasors & Regime Limits

Every harmonic oscillator in physics stems from one structural fact: **smooth potential wells look locally parabolic near a stable equilibrium**.

:::cue id=shm-lin-cue prop=phys-shm-linearization
Q: Why does a constant external force (like gravity on a vertical spring) leave the oscillation period completely unchanged?
A: Adding -F0*x tilts the potential energy curve and shifts the minimum x0 = F0/k, while the second derivative k = U''(x0) governing restoring acceleration stays identical.
:::

## Regime-Break Peeler: Small-Angle vs Exact Pendulum

Drag initial amplitude `theta0` past `0.35 rad` (~20 deg) to watch exact restoring torque `sin(theta)` peel away from the linear approximation `theta`, lengthening the true period.

:::explore shm-pendulum-regime
{
  "id": "shm-pendulum-regime",
  "title": "Small-Angle vs Exact Pendulum Regime-Break Peeler",
  "prompt": "Compare linear SHM torque (theta) against exact pendulum torque (sin(theta)) and inspect the period error as initial amplitude theta0 grows.",
  "params": [
    {"name": "theta0", "label": "Initial angle theta0", "min": 0.05, "max": 2.4, "step": 0.05, "default": 0.3, "unit": "rad"},
    {"name": "L", "label": "Length L", "min": 0.25, "max": 4.0, "step": 0.25, "default": 1.0, "unit": "m"},
    {"name": "g", "label": "Gravity g", "min": 1.6, "max": 20.0, "step": 0.2, "default": 9.8, "unit": "m/s^2"}
  ],
  "outputs": [
    {"label": "Small-angle period T0", "expr": "2 * pi * sqrt(L / g)", "unit": "s"},
    {"label": "Nonlinear period T_exact", "expr": "2 * pi * sqrt(L / g) * (1 + (theta0 ** 2) / 16 + 11 * (theta0 ** 4) / 3072)", "unit": "s"},
    {"label": "Period lengthen error", "expr": "100 * ((theta0 ** 2) / 16 + 11 * (theta0 ** 4) / 3072)", "unit": "%"}
  ],
  "curve": {
    "xVar": "theta",
    "xMin": 0.0,
    "xMax": 2.2,
    "samples": 48,
    "exactExpr": "sin(theta)",
    "approxExpr": "theta",
    "regimeThreshold": 0.35,
    "yLabel": "Restoring factor"
  },
  "limitCheck": {
    "question": "As theta0 -> 0, what value does the period ratio T_exact / T0 approach?",
    "var": "theta0",
    "target": 0,
    "expectedExpr": "1 + (theta0 ** 2) / 16",
    "expectedVal": 1.0,
    "hint": "Every higher-order amplitude term theta0^(2n) vanishes in the small-angle limit."
  }
}
:::

## Springs, Energy & Damped Resonance

1. **Energy oscillates at $2\omega$**: $K(t)$ and $U(t)$ reach two maxima per full displacement period.
2. **Series vs Parallel stiffness**: series springs share force ($1/k_{\text{eq}} = 1/k_1 + 1/k_2$); parallel springs share displacement ($k_{\text{eq}} = k_1 + k_2$).

:::cue id=shm-energy-cue prop=phys-shm-energy-curvature
Q: A mass executes SHM at 3 Hz. At what frequency does its kinetic energy oscillate?
A: 6 Hz (twice the displacement frequency), since K(t) = (1/2) m v^2 peaks on both the +x and -x passes through equilibrium.
:::
