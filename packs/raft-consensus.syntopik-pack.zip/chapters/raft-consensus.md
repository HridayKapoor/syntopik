# Raft Consensus — Safety Invariants & Fault Tolerance

Consensus reduces a replicated state machine to one disciplined question: **how do independent servers agree on a single ordered log despite crashes and network partitions?**

:::cue id=raft-quorum-cue prop=sys-raft-quorum
Q: What is the minimum cluster size N required to tolerate f simultaneous crash failures while preserving majority availability?
A: N = 2f + 1 servers (quorum Q = f + 1). An even size 2f gives no extra fault tolerance over 2f - 1 because Q = f + 1 leaves only f - 1 spare nodes.
:::

## Quorum Availability & Fault-Tolerance Explorer

Manipulate total servers `N` and crashed nodes `f` to see why odd cluster sizes minimize overhead while guaranteeing strict quorum overlap.

:::explore raft-quorum-lab
{
  "id": "raft-quorum-lab",
  "title": "Raft Quorum Overlap & Crash Tolerance Lab",
  "prompt": "Compare majority quorum Q = floor(N/2) + 1 against available nodes (N - f). Notice why N = 4 tolerates only f = 1 crash—no better than N = 3.",
  "params": [
    {"name": "N", "label": "Cluster size N", "min": 3, "max": 15, "step": 1, "default": 5, "unit": "nodes"},
    {"name": "f", "label": "Failed nodes f", "min": 0, "max": 7, "step": 1, "default": 1, "unit": "nodes"}
  ],
  "outputs": [
    {"label": "Majority quorum Q", "expr": "floor(N / 2) + 1", "unit": "nodes"},
    {"label": "Max crash tolerance", "expr": "floor((N - 1) / 2)", "unit": "nodes"},
    {"label": "Healthy margin (N - f - Q)", "expr": "(N - f) - (floor(N / 2) + 1)", "unit": "nodes"},
    {"label": "Min quorum overlap (2Q - N)", "expr": "2 * (floor(N / 2) + 1) - N", "unit": "nodes"}
  ],
  "curve": {
    "xVar": "x",
    "xMin": 3,
    "xMax": 15,
    "samples": 25,
    "exactExpr": "floor(x / 2) + 1",
    "approxExpr": "x / 2 + 0.5",
    "regimeThreshold": 9,
    "yLabel": "Quorum size Q(N)"
  },
  "limitCheck": {
    "question": "For a 5-node cluster (N = 5), what is the exact minimum quorum size Q?",
    "var": "N",
    "target": 5,
    "expectedExpr": "floor(N / 2) + 1",
    "expectedVal": 3,
    "hint": "Compute floor(5/2) + 1 so two quorums sum to 6 > 5."
  }
}
:::

## Log Matching & The Figure 8 Rule

Every committed entry must survive all future leader elections. That requires two guards working in conjunction:

1. **Up-to-Date Log Restriction**: compare `lastLogTerm` strictly *before* comparing log length.
2. **Current-Term Commit Rule**: a leader commits entries from previous terms only indirectly once an entry from its *current* term reaches a majority.

:::cue id=raft-fig8-cue prop=sys-raft-figure8-commit
Q: A term-4 leader sees a term-2 log entry replicated on 3 of 5 nodes. May it immediately advance commitIndex to that entry?
A: No. Under the Figure 8 rule, it must wait until a term-4 entry is replicated on a majority; counting replicas on an old-term entry can still be overwritten by a higher-term competitor.
:::
