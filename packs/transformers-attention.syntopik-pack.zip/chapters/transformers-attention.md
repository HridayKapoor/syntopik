# Transformers & Attention — Variance Scaling, Causality & KV-Cache

Scaled dot-product attention is simple algebra paired with one crucial numerical invariant: **keep pre-softmax logits at $O(1)$ variance so gradients survive**.

:::cue id=attn-var-cue prop=ml-attn-scaled-dot
Q: If head dimension grows from d_k = 64 to d_k = 4096 without 1/sqrt(d_k) scaling, what happens to softmax entropy and gradients?
A: Logit standard deviation jumps 8x (from 8 to 64), collapsing softmax into near-one-hot saturation where the Jacobian p_i(1 - p_i) vanishes.
:::

## Softmax Temperature & Variance-Scaling Lab

Sweep `d_k` and temperature `temp` to watch an unscaled two-token logit gap collapse into hard saturation while the `1/sqrt(d_k)`-scaled softmax keeps healthy gradient flow.

:::explore attn-softmax-scaling
{
  "id": "attn-softmax-scaling",
  "title": "Softmax Temperature & Variance-Scaling Saturation Lab",
  "prompt": "Compare scaled vs unscaled top attention probability and gradient strength p*(1-p) as head dimension d_k grows.",
  "params": [
    {"name": "d_k", "label": "Head dim d_k", "min": 16, "max": 1024, "step": 16, "default": 64, "unit": "dims"},
    {"name": "temp", "label": "Temperature T", "min": 0.2, "max": 4.0, "step": 0.1, "default": 1.0, "unit": ""},
    {"name": "delta", "label": "Unit logit gap delta", "min": 0.2, "max": 3.0, "step": 0.1, "default": 1.0, "unit": "sigma"}
  ],
  "outputs": [
    {"label": "Unscaled logit std", "expr": "sqrt(d_k)", "unit": ""},
    {"label": "Scaled top weight p", "expr": "1 / (1 + exp(-delta / temp))", "unit": ""},
    {"label": "Unscaled top weight", "expr": "1 / (1 + exp(-min(40, delta * sqrt(d_k) / temp)))", "unit": ""},
    {"label": "Scaled gradient p(1-p)", "expr": "(1 / (1 + exp(-delta / temp))) * (1 - 1 / (1 + exp(-delta / temp)))", "unit": ""}
  ],
  "curve": {
    "xVar": "x",
    "xMin": 0.0,
    "xMax": 6.0,
    "samples": 48,
    "exactExpr": "1 / (1 + exp(-x / temp))",
    "approxExpr": "min(1, 0.5 + x / (4 * temp))",
    "regimeThreshold": 2.0,
    "yLabel": "Top softmax weight"
  },
  "limitCheck": {
    "question": "As logit gap delta -> 0 at temp = 1, what attention weight does the scaled two-token softmax assign?",
    "var": "delta",
    "target": 0,
    "expectedExpr": "1 / (1 + exp(-delta / temp))",
    "expectedVal": 0.5,
    "hint": "Evaluate 1 / (1 + exp(0))."
  }
}
:::

## Causality, RoPE & KV-Cache Systems Cost

1. **Pre-softmax `-inf` mask**: zeroing future logits *before* softmax fails because $e^0 = 1$.
2. **KV-Cache + GQA**: causal invariance lets inference cache past $K, V$ ($O(T d)$ per decode step), and GQA cuts KV HBM bandwidth by $H_Q / H_{KV}$.

:::cue id=attn-causal-cue prop=ml-attn-causal-mask
Q: Why must causal masking happen BEFORE softmax using -inf rather than zeroing future weights after softmax?
A: Setting j > i logits to -inf makes exp(-inf) = 0 so the remaining valid positions i >= j automatically normalize to sum to 1 without leaking future probability mass.
:::
